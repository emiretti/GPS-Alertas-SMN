package com.estebanmiretti.gps

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.preference.PreferenceManager
import android.util.Log
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.estebanmiretti.gps.polygon.Point
import com.estebanmiretti.gps.polygon.Polygon
import okhttp3.OkHttpClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.simplexml.SimpleXmlConverterFactory


class RssLocationWorker(appContext: Context, workerParams: WorkerParameters) :
    CoroutineWorker(appContext, workerParams) {
    var wvTodos: StringBuilder = StringBuilder("")
    var notificationId: Int = 15
    val context = appContext

    override suspend fun doWork(): Result {
        // Do the work here--in this case, upload the images.
        readXmlFeed()
        // Indicate whether the work finished successfully with the Result
        return Result.success()
    }

    fun readXmlFeed() {
        val array: ArrayList<String> = ArrayList<String>()
        val latitud = inputData.getDouble("latitud", 0.0)
        val longitud = inputData.getDouble("longitud", 0.0)
        val retrofit = Retrofit.Builder().baseUrl("https://ssl.smn.gob.ar/feeds/")
            .client(OkHttpClient()).addConverterFactory(SimpleXmlConverterFactory.create()).build()
        val reader: ApiDataInterface = retrofit.create(ApiDataInterface::class.java)
        val call: Call<Rss> = reader.getData()

        call.enqueue(object : Callback<Rss> {
            override fun onResponse(call: Call<Rss>, response: Response<Rss>) {
                val mPref = PreferenceManager.getDefaultSharedPreferences(context)
                val editor = mPref.edit()
                var rssmessage: Rss?
                var arrayDeptos: List<String>? = null
                if (response.isSuccessful) {
                    rssmessage = response.body()
                    if (rssmessage != null) {
                        array.clear()
                        var arrayDeptosIsEmpty: Boolean = false
                        val strArrDeptos: String? = mPref.getString("deptos", null)
                        if (!strArrDeptos.isNullOrBlank()) {//.length>3)
                            arrayDeptos = (strArrDeptos.replace("[", "").replace("]", "")
                                .replace("\"", "")).split(",")
                        } else arrayDeptosIsEmpty = true
                        var wv: String?
                        var alarmas: String? = ""
                        var gpss: StringBuilder = StringBuilder("")
                        for (aviso in rssmessage.getChannel()?.getItem()!!) {
                            gpss.append(aviso?.getPolygon())
                            gpss.append("  ")
                            wv = aviso?.getDescription()
                            array.add(
                                wv!!.replace("\n", "").replace("\t", "").replace("\r", "")
                            )
                            val poly2: Polygon.Builder = Polygon.Builder()
                            var i = 0
                            if (!arrayDeptosIsEmpty) {
                                var ii = 0
                                while (ii < arrayDeptos?.size!!) {
                                    if (wv.contains(arrayDeptos[ii], true)) {
                                        if (alarmas.isNullOrEmpty()) alarmas += arrayDeptos[ii]
                                        else alarmas += ", " + arrayDeptos[ii]
                                        if (!wvTodos.isEmpty()) wvTodos.append("<br><hr>" + wv)
                                        else wvTodos.append(wv)
                                        break
                                    }
                                    ii++
                                }
                            }
                            val answer = aviso!!.getPolygon()
                            var arrayLatLng: List<String>? = null
                            if (answer != null) {
                                arrayLatLng = answer.split(" ")
                                while (i < arrayLatLng.size) {
                                    poly2.addVertex(
                                        Point(
                                            arrayLatLng[i].toDouble(),
                                            arrayLatLng[++i].toDouble()
                                        )
                                    )

                                    i++
                                }
                                val polygon2 = poly2.build()
                                val point = Point(latitud, longitud)
                                if (polygon2.contains(point)) {
                                    if (alarmas.isNullOrEmpty()) alarmas += "Locación Actual"
                                    else alarmas += ", " + "Locación Actual"
                                    if (!wvTodos.isNullOrEmpty()) wvTodos.append("<br><hr>" + wv)
                                    else wvTodos.append(wv)
                                }
                            }
                        }
                        editor.putString("gpss", gpss.toString())//////
                        editor.putString("dire", inputData.getString("direccion"))
                        editor.putFloat("lati", latitud.toFloat())
                        editor.putFloat("longi", longitud.toFloat())

                        if (!alarmas?.isNullOrEmpty()!!){
                            // 1. Lanza la notificación del sistema
                            notificationManager.notify(
                                notificationId, createNotification("Alertas: " + alarmas)
                            )

                            // 2. Ejecuta tu efecto de sonido personalizado en segundo plano
                            GestorSonido.reproducirAlerta(context)
                        }

                        if (!array.isNullOrEmpty() )
                            editor.putString("alertas", convertStringArrayToString(array, "$"))
                        else if(!array[0].equals("No se han emitido Avisos Meteorológicos a corto plazo en la REPUBLICA ARGENTINA"))
                            Handler(Looper.getMainLooper()).post {
                                Toast.makeText(
                                    context,
                                    "Actualizando: " + array.size + " avisos",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        else Handler(Looper.getMainLooper()).post {
                            Toast.makeText(
                                context,
                                "Actualizando...",
                                Toast.LENGTH_SHORT
                            ).show()
                        }



                    } else {
                    }
                } else {
                }
                editor.apply()
                editor.commit()


            }

            override fun onFailure(call: Call<Rss>, t: Throwable) {
               /*val mPref = PreferenceManager.getDefaultSharedPreferences(context)
                val editor = mPref.edit()
                editor.putString(
                    "alertas", "Algo falló)=" + t.message
                )
                editor.apply()
                editor.commit()*/
               t.message?.let { Log.e("Fail: ", it) }

                Handler(Looper.getMainLooper()).post {
                    Toast.makeText(
                        context, "Actualizando: " + t.message, Toast.LENGTH_SHORT
                    ).show()
                }
            }

        })

    }
    private val notificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager


    private fun createNotification(st: String): Notification {

        val intent = Intent(context, Alarma::class.java)
        intent.putExtra("wv", wvTodos.toString())
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)

        val pendingIntent = PendingIntent.getActivity(
            context,
            0 /* Request code */,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_MUTABLE

        )
        val channelId = context.getString(R.string.notification_channel_id)
        val title: String = "Aviso de Corto Plazo"
        val builder = NotificationCompat.Builder(context, channelId).setContentTitle(title)
            .setContentText(st)
            .setSmallIcon(android.R.drawable.alert_dark_frame).setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setOnlyAlertOnce(true).setAutoCancel(true).setOngoing(true)
        val name = context.getString(R.string.channel_name)
        createNotificationChannel(channelId, name).also {
            builder.setChannelId(it.id).priority = NotificationCompat.PRIORITY_HIGH
        }
        return builder.build()
    }

    /**
     * Create the required notification channel for O+ devices.
     */
    private fun createNotificationChannel(
        channelId: String, name: String
    ): NotificationChannel {
        return NotificationChannel(
            channelId, name, NotificationManager.IMPORTANCE_HIGH
        ).also { channel ->
            notificationManager.createNotificationChannel(channel)
        }
    }


    private fun convertStringArrayToString(strArr: ArrayList<String>, delimiter: String): String? {
        val sb = StringBuilder()
        for (str in strArr) sb.append(str).append(delimiter)
        return sb.substring(0, sb.length - 1)
    }
}