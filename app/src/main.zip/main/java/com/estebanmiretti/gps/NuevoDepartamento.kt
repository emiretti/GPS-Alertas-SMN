package com.estebanmiretti.gps

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.preference.PreferenceManager
import android.preference.PreferenceManager.getDefaultSharedPreferences
import android.view.Menu
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.lang.reflect.Type

class NuevoDepartamento : AppCompatActivity() {
    var myListView: ListView? = null
    private var adapter: ArrayAdapter<String>? = null
    private var array: ArrayList<String> = ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_nuevo_departamento)
        myListView = findViewById<ListView>(R.id.listView1)
        val prefs = getDefaultSharedPreferences(this)
        val jsonText: String? = prefs.getString("deptos", null)

        if (jsonText != null) {
            array = ArrayList<String>((jsonText?.replace("[","")
                ?.replace("]","")
                ?.replace("\"\"",""))?.split(","))


        }
        val btnAgregarCiudad = findViewById<Button>(R.id.btnAgregarDepto)
        btnAgregarCiudad.setOnClickListener {
            val editTextValor = findViewById<EditText>(R.id.editTextValor)
            if (editTextValor.text.isEmpty()) {
                Toast.makeText(
                    this, resources.getString(R.string.msg_validation),
                    Toast.LENGTH_LONG
                ).show()
            } else {
                //val inputValue = java.lang.Float.parseFloat(editTextValor.text.toString())
                    agregarDepartamento(editTextValor.text.toString())
                val datos = Intent()
                datos.putExtra("variable", editTextValor.text.toString())
                setResult(Activity.RESULT_OK, datos)
                finish()
            }
        }

        adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,
            //android.R.layout.text1,
            array
        )

        myListView?.adapter = adapter

        myListView?.onItemLongClickListener =
            AdapterView.OnItemLongClickListener { parent, _, position, _ ->

                borrarDepartamento(parent.getItemAtPosition(position) as String)

            }

        /*myListView.onItemClickListener = AdapterView.OnItemClickListener { parent, _, position, _ ->
            val selectedFromList = parent.getItemAtPosition(position) as String
            getTemperature("$selectedFromList")
        }*/
    }

    fun borrarDepartamento(q: String?): Boolean {
        if (!array.contains(q)) {
            return false
        }
        if (q != null) {
            val prefs = getDefaultSharedPreferences(baseContext)
            val editor = prefs.edit()
            val gson = Gson()
            array.remove(q)
if(array.isEmpty()) array.clear()
            val jsonText = gson.toJson(array)
            editor.putString(
                "deptos", jsonText
                    ?.replace("]","")
                    ?.replace("\"\",","")
                    ?.replace("[,","")
                    ?.replace("[","")
                    ?.replace("\"","")
            )

            editor.apply()
            editor.commit()
            adapter!!.notifyDataSetChanged()

            Toast.makeText(
                getApplicationContext(),
                "Se eliminó " + q,
                Toast.LENGTH_LONG
            ).show()
        }

        return true
    }

    fun agregarDepartamento(q: String?) {
        if (array.contains(q)) {
            return
        }
        if (q != null) {
            val prefs = getDefaultSharedPreferences(baseContext)
            val editor = prefs.edit()
            val gson = Gson()
            array.add(q)
            val jsonText = gson.toJson(array)
            editor.putString(
                "deptos", jsonText?.replace("]","")
                    ?.replace("\"\",","")
                    ?.replace("[,","")
                    ?.replace("[","")
                    ?.replace("\"","")
            )
            editor.apply()
            editor.commit()

            adapter!!.notifyDataSetChanged()

        }
    }

}