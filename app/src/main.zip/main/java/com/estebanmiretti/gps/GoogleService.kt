package com.estebanmiretti.gps

import android.Manifest
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Binder
import android.os.Bundle
import android.os.IBinder
import android.preference.PreferenceManager
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.work.Data
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.io.IOException
import java.util.*
import java.util.concurrent.TimeUnit


class GoogleService : Service(), LocationListener {
    private val maxResultados: Int = 1
    private val minTimeMs_gps: Long = 60 * 1000//
    private var isGPSEnable = false
    private var isNetworkEnable = false
    private var latitude: Double = 0.0
    private var longitude: Double = 0.0
    private var provincia: String = ""
    private var departamento: String = ""
    private var localidad: String = ""
    private var direccion: String = ""
    private var locationManager: LocationManager? = null
    private var location: Location? = null

    private var intent: Intent = Intent(str_receiver)


    override fun onCreate() {
        super.onCreate()
        //fn_getlocation()


    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val myRssLocationWork = PeriodicWorkRequestBuilder<RssLocationWorker>(
            /*20, TimeUnit.SECONDS, */// repeatInterval (the period cycle)
            15, TimeUnit.MINUTES
        ) // flexInterval
            .setInputData(createInputData()).build()


        WorkManager.getInstance(applicationContext)//.getWorkInfoById(myRssLocationWork.id)
            .enqueue(myRssLocationWork)


        return super.onStartCommand(intent, flags, startId)

    }

    private fun createInputData(): Data {
        fn_getlocation()
        val builder = Data.Builder()
        builder.putDouble("latitud", latitude)
        builder.putDouble("longitud", longitude)
        builder.putString("direccion", direccion)
        return builder.build()
    }

    override fun onLocationChanged(p0: Location) {
        // Toast.makeText(applicationContext, "@@ " + direccion, Toast.LENGTH_LONG);
    }

    @Deprecated("Deprecated in Java")
    override fun onStatusChanged(provider: String, status: Int, extras: Bundle) {
    }

    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}

    fun fn_getlocation() {
        locationManager = applicationContext.getSystemService(LOCATION_SERVICE) as LocationManager
        isGPSEnable = locationManager!!.isProviderEnabled(LocationManager.GPS_PROVIDER)
        isNetworkEnable = locationManager!!.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
        if (!isGPSEnable && !isNetworkEnable) {
            //Toast.makeText(this, "!isGPSEnable && !isNetworkEnable", Toast.LENGTH_SHORT).show()
        } else {
            if (isNetworkEnable) {
                location = null

                if (ActivityCompat.checkSelfPermission(
                        this, Manifest.permission.ACCESS_FINE_LOCATION
                    ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                        this, Manifest.permission.ACCESS_COARSE_LOCATION
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    /* ActivityCompat.requestPermissions(
                         MainActivity,
                         arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,
                             Manifest.permission.ACCESS_COARSE_LOCATION),
                         MY_PERMISSIONS_REQUEST_CODE)*/
                } else {
                    locationManager!!.requestLocationUpdates(
                        LocationManager.NETWORK_PROVIDER, minTimeMs_gps, 0f, this
                    )
                    if (locationManager != null) {
                        location =
                            locationManager!!.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                        if (location != null) {
                            //Log.e("map tracker lat", location!!.latitude.toString() + "")
                            //Log.e("map tracker long", location!!.longitude.toString() + "")
                            latitude = location!!.latitude
                            longitude = location!!.longitude
                            fn_update()
                        }
                    } else {
                        if (isGPSEnable) {
                            location = null
                            locationManager!!.requestLocationUpdates(
                                LocationManager.GPS_PROVIDER, minTimeMs_gps, 0f, this
                            )
                            if (locationManager != null) {
                                location =
                                    locationManager!!.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                                if (location != null) {
                                    //Log.e("map tracker lat1", location!!.latitude.toString() + "")
                                    //Log.e("map tracker long1", location!!.longitude.toString() + "")
                                    latitude = location!!.latitude
                                    longitude = location!!.longitude
                                    fn_update()
                                }
                            }
                        }
                    }
                }
            }

        }
    }


    private val mBinder: IBinder = LocalBinder()

    inner class LocalBinder : Binder() {
        fun getService(): GoogleService {
            return this@GoogleService
        }
    }

    override fun onBind(intent: Intent?): IBinder {
        return mBinder
    }

    fun fn_update() {
        val lat = location?.latitude
        val lon = location?.longitude
        if (lat != null && lon != null) {
            devuelveDepartamentoNombre(lat, lon)
        }
        intent.putExtra("latutide", lat)
        intent.putExtra("longitude", lon)
        intent.putExtra("localidad", localidad)
        intent.putExtra("provincia", provincia)
        intent.putExtra("departamento", departamento)
        intent.putExtra("direccion", direccion)
        // Log.e("map tracker", "enviando datos" + direccion)
        sendBroadcast(intent)

    }

    companion object {
        val str_receiver = "com.estebanmiretti.gps.receiver"
    }

    fun devuelveDepartamento(lat: Double, lng: Double): String {
        val geoCoder = Geocoder(applicationContext, Locale.getDefault())
        var str: String = ""
        try {
            if (!geoCoder.getFromLocation(lat, lng, maxResultados)
                    ?.get(0)?.locality.isNullOrEmpty()
            ) {
                str = geoCoder.getFromLocation(lat, lng, maxResultados)?.get(0)?.locality + ", "
            }
        } catch (n: NullPointerException) {
            n.printStackTrace()
        } catch (e: IOException) {
            e.printStackTrace()
        }
        try {
            str += geoCoder.getFromLocation(lat, lng, maxResultados)!!.get(0).subAdminArea
        } catch (n: NullPointerException) {
            n.printStackTrace()
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return str
    }

    fun devuelveDepartamentoNombre(lat: Double, lng: Double) {
        val geoCoder = Geocoder(applicationContext, Locale.getDefault())
        try {
            val addresses = geoCoder.getFromLocation(lat, lng, maxResultados)
            if (addresses != null) {
                provincia = addresses[0].adminArea
                departamento = addresses[0].subAdminArea
                localidad = addresses[0].locality
                direccion = addresses[0].getAddressLine(0)
            } else {
                // Log.e("map tracker", "geocoder... devuelveDepartamentoNombre")
            }
        } catch (e: IOException) {
            e.printStackTrace()
            //Toast.makeText(this, e.toString(), Toast.LENGTH_LONG)
        }
    }
    override fun onDestroy() {
        locationManager?.removeUpdates(this)
        super.onDestroy()
    }

    /*
    override fun onDestroy() {
        super.onDestroy()
        val mPref = PreferenceManager.getDefaultSharedPreferences(applicationContext)

        val editor = mPref.edit()

        editor.putString("dire", direccion)
        editor.putFloat("lati", latitud.toFloat())
        editor.putFloat("longi", longitud.toFloat())
    }
    */
}