package com.estebanmiretti.gps

import java.io.BufferedReader
import java.io.InputStreamReader
import android.content.Context
import android.util.Log
import android.preference.PreferenceManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory

class RssLocationWorker(
    context: Context,
    workerParams: WorkerParameters
) : Worker(context, workerParams) {

    override fun doWork(): Result {
        val latitudUsuario = inputData.getDouble("latitud", -30.33)
        val longitudUsuario = inputData.getDouble("longitud", -61.33)

        // URL Oficial de Alertas del SMN de Argentina (GeoRSS)
        val urlFeed = "https://ssl.smn.gob.ar/feeds/avisocorto_GeoRSS.xml"

        return try {
            Log.d("RssLocationWorker", "Descargando feed de alertas SMN...")
            val stream = descargarXml(urlFeed)

            // Procesamos el XML completo
            parsearGeoXmlYGuardar(stream, latitudUsuario, longitudUsuario)

            Result.success()
        } catch (e: Exception) {
            Log.e("RssLocationWorker", "Error descargando feed GeoRSS", e)
            Result.retry()
        }
    }

    private fun descargarXml(urlString: String): InputStream {
        val url = URL(urlString)
        val conn = url.openConnection() as HttpURLConnection
        conn.readTimeout = 8000
        conn.connectTimeout = 8000
        conn.requestMethod = "GET"
        conn.connect()
        return conn.inputStream
    }

    private fun parsearGeoXmlYGuardar(inputStream: InputStream, latUser: Double, lonUser: Double) {
        val reader = BufferedReader(InputStreamReader(inputStream, "UTF-8"))
        var contenidoXml = reader.use { it.readText() }

        if (contenidoXml.startsWith("\uFEFF")) {
            contenidoXml = contenidoXml.substring(1)
        }

        val factory = XmlPullParserFactory.newInstance()
        factory.isNamespaceAware = true
        val parser = factory.newPullParser()
        parser.setInput(contenidoXml.reader())

        var eventType = parser.eventType
        var tituloActual = ""
        var descripcionActual = ""
        var geoPolygonActual = ""
        var dentroDeItem = false

        val acumuladorAlertasTexto = StringBuilder()
        val acumuladorGpssCoordenadas = StringBuilder()

        while (eventType != XmlPullParser.END_DOCUMENT) {
            val tagName = parser.name

            when (eventType) {
                XmlPullParser.START_TAG -> {
                    if (tagName != null && tagName.equals("item", ignoreCase = true)) {
                        dentroDeItem = true
                    }

                    if (dentroDeItem && tagName != null) {
                        try {
                            when {
                                tagName.endsWith("title", ignoreCase = true) -> tituloActual = parser.nextText()
                                tagName.endsWith("description", ignoreCase = true) -> descripcionActual = parser.nextText()
                                // Capturamos polígonos GeoRSS o puntos (ajustado según la estructura del SMN)
                                tagName.endsWith("polygon", ignoreCase = true) -> geoPolygonActual = parser.nextText()
                                tagName.endsWith("point", ignoreCase = true) && geoPolygonActual.isEmpty() -> geoPolygonActual = parser.nextText()
                            }
                        } catch (e: Exception) {
                            Log.e("WorkerXML", "Error leyendo tags", e)
                        }
                    }
                }

                XmlPullParser.END_TAG -> {
                    if (tagName != null && tagName.equals("item", ignoreCase = true)) {

                        // 1. Verificamos coincidencia geográfica básica (puedes ajustar el filtro si es estricto)
                        if (coincideZona(geoPolygonActual, latUser, lonUser)) {

                            // Formato HTML que espera tu ArrayAdapter
                            val bloqueHtml = "<h3>$tituloActual</h3><p>$descripcionActual</p>"

                            if (acumuladorAlertasTexto.isNotEmpty()) {
                                acumuladorAlertasTexto.append("$")
                            }
                            acumuladorAlertasTexto.append(bloqueHtml)

                            // 2. Formateamos la cadena de coordenadas espaciales para tu split("\\s\\s")
                            if (geoPolygonActual.isNotEmpty()) {
                                if (acumuladorGpssCoordenadas.isNotEmpty()) {
                                    acumuladorGpssCoordenadas.append("  ") // Doble espacio requerido por tu split
                                }
                                acumuladorGpssCoordenadas.append(geoPolygonActual.trim())
                            }
                        }

                        tituloActual = ""
                        descripcionActual = ""
                        geoPolygonActual = ""
                        dentroDeItem = false
                    }
                }
            }
            eventType = parser.next()
        }

        // 🔥 ALIMENTACIÓN COMPATIBLE: Guardamos las dos llaves exactas que busca tu MainActivity
        val mPref = PreferenceManager.getDefaultSharedPreferences(applicationContext)
        with(mPref.edit()) {
            putString("alertas", acumuladorAlertasTexto.toString())
            putString("gpss", if (acumuladorGpssCoordenadas.isEmpty()) null else acumuladorGpssCoordenadas.toString())
            apply()
        }
        Log.d("RssLocationWorker", "Datos inyectados con éxito en 'alertas' y 'gpss'.")
    }

    private fun coincideZona(geoCadena: String, latUser: Double, lonUser: Double): Boolean {
        if (geoCadena.isEmpty()) return true // Si el item no está georreferenciado, lo incluimos por seguridad
        return try {
            // Tolerancia amplia para que los polígonos no se oculten por falsos negativos
            val partes = geoCadena.trim().split("\\s+".toRegex())
            if (partes.size >= 2) {
                val latAlerta = partes[0].toDouble()
                val lonAlerta = partes[1].toDouble()
                Math.abs(latAlerta - latUser) < 3.5 && Math.abs(lonAlerta - lonUser) < 3.5
            } else {
                true
            }
        } catch (e: Exception) {
            true
        }
    }
}
