package com.estebanmiretti.gps

import android.app.Activity
import android.app.ActivityManager
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.IBinder
import android.preference.PreferenceManager
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.work.Data
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.maps.model.PolygonOptions
import java.text.SimpleDateFormat
import java.util.Date

class MainActivity : AppCompatActivity(), OnMapReadyCallback {
    private var mMap: GoogleMap? = null
    private var localidad: String? = null
    private var direccion: String? = null
    private var departamento: String? = null
    var latitud: Double = -30.33
    var longitud: Double = -61.33
    var mBound: Boolean = false
    var mService: GoogleService? = null
    private val REQUEST_PERMISSIONS = 100
    var boolean_permission = false
    var tv_address: TextView? = null
    private lateinit var adapter: ArrayAdapter<String>
    private var array1: Array<String>? = arrayOf("")

    private val mConnection = object : ServiceConnection {
        override fun onServiceConnected(className: ComponentName, service: IBinder) {
            val binder = service as GoogleService.LocalBinder
            mService = binder.getService()
            mBound = true
        }
        override fun onServiceDisconnected(arg0: ComponentName) {
            mBound = false
        }
    }

    private fun isMyServiceRunning(serviceClass: Class<*>): Boolean {
        val manager = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        for (service in manager.getRunningServices(Int.MAX_VALUE)) {
            if (serviceClass.name == service.service.className) {
                return true
            }
        }
        return false
    }

    override fun onStart() {
        super.onStart()
        tv_address!!.text = "chequeando..."
        registerReceiver(broadcastReceiver, IntentFilter("googleService"))
        doBindService()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        fn_permission()
        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
        tv_address = findViewById<View>(R.id.tv_address) as TextView
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return true
    }

    // 🔥 RESTAURADO AL 100%: Tu navegación nativa a NuevoDepartamento
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        val i = Intent(this, NuevoDepartamento::class.java)

        when (id) {
            R.id.AgregarDepartamento -> {
                launchSomeActivity.launch(i)
            }
        }
        return super.onOptionsItemSelected(item)
    }

    // 🔥 RESTAURADO AL 100%: Tu recibidor de datos del formulario de departamento
    var launchSomeActivity =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val data: Intent? = result.data
                Toast.makeText(
                    applicationContext,
                    "Alerta agregada: " + data?.getStringExtra("variable").toString(),
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap
        mMap?.setOnMapLongClickListener(object : GoogleMap.OnMapLongClickListener {
            override fun onMapLongClick(latlng: LatLng) {
                val location = LatLng(latlng.latitude, latlng.longitude)
                val departm = mService?.devuelveDepartamento(latlng.latitude, latlng.longitude)
                mMap?.addMarker(MarkerOptions().position(location).title(departm.toString()))
            }
        })
    }

    fun doBindService() {
        val intento = Intent(applicationContext, GoogleService::class.java)
        if (!mBound && !isMyServiceRunning(GoogleService::class.java)) {
            Toast.makeText(applicationContext, "Iniciando servicio", Toast.LENGTH_SHORT).show()
            startService(intento)
            bindService(intento, mConnection, BIND_AUTO_CREATE)
        } else if (!mBound) {
            bindService(intento, mConnection, BIND_AUTO_CREATE)
        }
    }

    private fun fn_permission() {
        if (ContextCompat.checkSelfPermission(applicationContext, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this@MainActivity, arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION), REQUEST_PERMISSIONS)
        } else {
            boolean_permission = true
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String?>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            REQUEST_PERMISSIONS -> {
                if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    boolean_permission = true
                } else {
                    Toast.makeText(applicationContext, "Por favor, habilite el permiso", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private val broadcastReceiver: BroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent) {
            val mPref = PreferenceManager.getDefaultSharedPreferences(applicationContext)
            latitud = intent.getDoubleExtra("latutide", mPref.getFloat("lati", 0.0F).toDouble())
            longitud = intent.getDoubleExtra("longitude", mPref.getFloat("longi", 0.0F).toDouble())
            localidad = intent.getStringExtra("localidad")
            departamento = intent.getStringExtra("departamento")

            val s: SimpleDateFormat = SimpleDateFormat("EEE dd/MM/yy hh:mm:ss")
            val format: String = s.format(Date())

            if (!intent.getStringExtra("direccion").isNullOrBlank())
                direccion = format + ". " + intent.getStringExtra("direccion")
            else
                direccion = mPref.getString("dire", "")

            cargarDatos()
            tv_address!!.text = direccion + ", departamento " + departamento

            // Lanzamiento en segundo plano del Worker de red sin alterar hilos visuales
            dispararWorkerDeRedSilencioso()
        }
    }

    private fun createInputData(): Data {
        val builder = Data.Builder()
        builder.putDouble("latitud", latitud)
        builder.putDouble("longitud", longitud)
        builder.putString("direccion", direccion)
        return builder.build()
    }

    private fun dispararWorkerDeRedSilencioso() {
        val datosGps = createInputData()
        val workManager = WorkManager.getInstance(applicationContext)

        val disparoInmediato = OneTimeWorkRequestBuilder<RssLocationWorker>()
            .setInputData(datosGps)
            .build()

        workManager.enqueue(disparoInmediato)

        workManager.getWorkInfoByIdLiveData(disparoInmediato.id)
            .observe(this) { workInfo ->
                if (workInfo != null && workInfo.state.isFinished) {
                    Log.d("MainActivity", "Worker finalizado. Actualizando interfaz...")
                    cargarDatos()
                }
            }
    }

    fun addPolygono(arg: ArrayList<LatLng>): PolygonOptions {
        val polygonOptions = PolygonOptions().strokeColor(Color.RED).strokeWidth(1f)
            .fillColor(Color.parseColor("#ea9999"))
        return polygonOptions.addAll(arg)
    }

    override fun onStop() {
        super.onStop()
        try {
            unregisterReceiver(broadcastReceiver)
        } catch (e: Exception) { }
        if (mBound) {
            unbindService(mConnection)
            mBound = false
        }
    }

    private fun cargarDatos() {
        val mPref = PreferenceManager.getDefaultSharedPreferences(applicationContext)
        mMap?.clear()
        mMap?.addMarker(
            MarkerOptions().position(LatLng(mPref.getFloat("lati", latitud.toFloat()).toDouble(), mPref.getFloat("longi", longitud.toFloat()).toDouble())).title(localidad)
        )
        val arrayText: String? = mPref.getString("alertas", null)
        val arrayGpss: String? = mPref.getString("gpss", null)

        var arrayLatLng: Array<String> = emptyArray()
        if (!arrayGpss.isNullOrBlank()) {
            arrayLatLng = arrayGpss.trim().split("\\s\\s".toRegex()).toTypedArray()
            for (i in 0 until arrayLatLng.size) {
                var j = 0
                val arrayL: Array<String> = arrayLatLng[i].split("\\s".toRegex()).toTypedArray()
                if (!arrayL.equals("null")) {
                    var options: ArrayList<LatLng> = ArrayList()
                    while (j < arrayL.size) {
                        val poin = LatLng((arrayL.get(j).toDouble()), (arrayL.get(j + 1).toDouble()))
                        options.add(poin)
                        j = j + 2
                    }
                    mMap?.addPolygon(addPolygono(options))
                }
            }
        }

        mMap?.animateCamera(CameraUpdateFactory.newLatLngZoom(LatLng(-30.33, -61.33), 4.6f))
        val myListView = findViewById<ListView>(R.id.ListView01)
        myListView.onItemClickListener = AdapterView.OnItemClickListener { parent, _, position, _ ->
            val selectedFromList = parent.getItemAtPosition(position) as String
        }
        if (!arrayText.isNullOrEmpty()) {
            array1 = arrayText.split("$").toTypedArray()
            myListView.adapter = null
        }
        adapter = object : ArrayAdapter<String>(this, R.layout.new_list_view, array1!!) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val row: View
                row = convertView ?: layoutInflater.inflate(R.layout.new_list_view, null)

                // Buscamos el WebView original tal como estaba diseñado
                val tv = row.findViewById<View>(android.R.id.text1) as WebView

                tv.loadData(
                    "<html><head><style>body{margin-left: auto; margin-top: 20px; margin-right: auto; max-width: 85%;}img{display: inline; height: auto;display: block; margin-left: auto; margin-right: auto; max-width: 100%; }</style>\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"></head>\n<body>" + getItem(position) + "</body></html>", "text/html", "UTF-8"
                )
                return row
            }
        }
        myListView.adapter = this.adapter
        adapter.notifyDataSetChanged()
    }
}