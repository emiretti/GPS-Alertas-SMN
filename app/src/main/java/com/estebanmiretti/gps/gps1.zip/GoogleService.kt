package com.estebanmiretti.gps

import android.Manifest
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Binder
import android.os.Bundle
import android.os.IBinder
import android.preference.PreferenceManager
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.work.Data
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.io.IOException
import java.util.*
import java.util.concurrent.TimeUnit


class GoogleService : Service(), LocationListener {
    private val maxResultados: Int = 1
    private val minTimeMs_gps: Long = 60 * 1000//
    private var isGPSEnable = false
    private var isNetworkEnable = false
    private var latitude: Double = 0.0
    private var longitude: Double = 0.0
    private var provincia: String = ""
    private var departamento: String = ""
    private var localidad: String = ""
    private var direccion: String = ""
    private var locationManager: LocationManager? = null
    private var location: Location? = null

    private var intent: Intent = Intent(str_receiver)


    override fun onCreate() {
        super.onCreate()
        //fn_getlocation()


    }

    /*override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val myRssLocationWork = PeriodicWorkRequestBuilder<RssLocationWorker>(
            //20, TimeUnit.SECONDS, // repeatInterval (the period cycle)
            15, TimeUnit.MINUTES
        ) // flexInterval
            .setInputData(createInputData()).build()


        WorkManager.getInstance(applicationContext)//.getWorkInfoById(myRssLocationWork.id)
            .enqueue(myRssLocationWork)


        return super.onStartCommand(intent, flags, startId)

    }*/
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // 1. Configurar la tarea periódica respetando los límites de Android (Mínimo 15 minutos)
        val myRssLocationWork = PeriodicWorkRequestBuilder<RssLocationWorker>(
            15, TimeUnit.MINUTES // Se ejecuta de forma segura cada 15 minutos
        )
            .setInputData(createInputData())
            .build()

        // 2. Encolar como trabajo ÚNICO para evitar duplicados si el servicio se reinicia
        WorkManager.getInstance(applicationContext).enqueueUniquePeriodicWork(
            "LectorAlertasGeoRSS",           // Nombre único para identificar la tarea
            ExistingPeriodicWorkPolicy.KEEP, // KEEP: Si ya existe una tarea corriendo, la mantiene intacta y no la duplica
            myRssLocationWork
        )

        // 3. Retorno explícito para servicios en segundo plano estables
        return START_STICKY // Si el sistema mata el servicio por falta de RAM, lo recreará cuando se libere
    }


    /*private fun createInputData(): Data {
        fn_getlocation()
        val builder = Data.Builder()
        builder.putDouble("latitud", latitude)
        builder.putDouble("longitud", longitude)
        builder.putString("direccion", direccion)
        return builder.build()
    }

    override fun onLocationChanged(p0: Location) {
        // Toast.makeText(applicationContext, "@@ " + direccion, Toast.LENGTH_LONG);
    }*/

    @Deprecated("Deprecated in Java")
    override fun onStatusChanged(provider: String, status: Int, extras: Bundle) {
    }

    override fun onProviderEnabled(provider: String) {}
    override fun onProviderDisabled(provider: String) {}

    fun fn_getlocation() {
        locationManager = applicationContext.getSystemService(LOCATION_SERVICE) as LocationManager

        // 1. Verificar qué proveedores están disponibles
        isGPSEnable = locationManager!!.isProviderEnabled(LocationManager.GPS_PROVIDER)
        isNetworkEnable = locationManager!!.isProviderEnabled(LocationManager.NETWORK_PROVIDER)

        if (!isGPSEnable && !isNetworkEnable) {
            return // No hay proveedores activos, salimos de la función de forma segura
        }

        // 2. Control riguroso de permisos requerido por Android
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return // Sin permisos concedidos no podemos continuar
        }

        location = null

        // 3. Estrategia por Red (Rápida pero menos precisa)
        if (isNetworkEnable) {
            locationManager!!.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, minTimeMs_gps, 0f, this)
            location = locationManager!!.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
        }

        // 4. Estrategia por GPS (Si la red falló o se requiere el satélite)
        if (location == null && isGPSEnable) {
            locationManager!!.requestLocationUpdates(LocationManager.GPS_PROVIDER, minTimeMs_gps, 0f, this)
            location = locationManager!!.getLastKnownLocation(LocationManager.GPS_PROVIDER)
        }

        // 5. Si logramos obtener la ubicación por cualquiera de las dos vías, actualizamos
        if (location != null) {
            latitude = location!!.latitude
            longitude = location!!.longitude
            fn_update()
        }
    }


    /**
     * Binder local que expone la instancia del servicio a los componentes de la interfaz de usuario.
     * Permite a la MainActivity invocar métodos de localización de forma directa y segura.
     */
    private val mBinder: IBinder = LocalBinder()

    inner class LocalBinder : Binder() {
        fun getService(): GoogleService = this@GoogleService
    }


    override fun onBind(intent: Intent?): IBinder {
        return mBinder
    }

    fun fn_update() {
        val lat = location?.latitude
        val lon = location?.longitude
        if (lat != null && lon != null) {
            devuelveDepartamentoNombre(lat, lon)
        }
        intent.putExtra("latutide", lat)
        intent.putExtra("longitude", lon)
        intent.putExtra("localidad", localidad)
        intent.putExtra("provincia", provincia)
        intent.putExtra("departamento", departamento)
        intent.putExtra("direccion", direccion)
        // Log.e("map tracker", "enviando datos" + direccion)
        sendBroadcast(intent)

    }

    companion object {
        val str_receiver = "com.estebanmiretti.gps.receiver"
    }

    fun devuelveDepartamento(lat: Double, lng: Double): String {
        val geoCoder = Geocoder(applicationContext, Locale.getDefault())
        var str: String = ""
        try {
            if (!geoCoder.getFromLocation(lat, lng, maxResultados)
                    ?.get(0)?.locality.isNullOrEmpty()
            ) {
                str = geoCoder.getFromLocation(lat, lng, maxResultados)?.get(0)?.locality + ", "
            }
        } catch (n: NullPointerException) {
            n.printStackTrace()
        } catch (e: IOException) {
            e.printStackTrace()
        }
        try {
            str += geoCoder.getFromLocation(lat, lng, maxResultados)!!.get(0).subAdminArea
        } catch (n: NullPointerException) {
            n.printStackTrace()
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return str
    }

    fun devuelveDepartamentoNombre(lat: Double, lng: Double) {
        val geoCoder = Geocoder(applicationContext, Locale.getDefault())
        try {
            val addresses = geoCoder.getFromLocation(lat, lng, maxResultados)
            if (addresses != null) {
                provincia = addresses[0].adminArea
                departamento = addresses[0].subAdminArea
                localidad = addresses[0].locality
                direccion = addresses[0].getAddressLine(0)
            } else {
                // Log.e("map tracker", "geocoder... devuelveDepartamentoNombre")
            }
        } catch (e: IOException) {
            e.printStackTrace()
            //Toast.makeText(this, e.toString(), Toast.LENGTH_LONG)
        }
    }
    override fun onDestroy() {
        locationManager?.removeUpdates(this)
        super.onDestroy()
    }

    /*
    override fun onDestroy() {
        super.onDestroy()
        val mPref = PreferenceManager.getDefaultSharedPreferences(applicationContext)

        val editor = mPref.edit()

        editor.putString("dire", direccion)
        editor.putFloat("lati", latitud.toFloat())
        editor.putFloat("longi", longitud.toFloat())
    }
    */
    // 1. Asegúrate de actualizar tus variables globales cuando el GPS realmente responda
    override fun onLocationChanged(p0: Location) {
        latitude = p0.latitude
        longitude = p0.longitude
        fn_update() // Envía el broadcast a MainActivity para actualizar el mapa en tiempo real
    }

    // 2. Modifica createInputData para que capture la ubicación actual de forma inmediata
    private fun createInputData(): Data {
        // Forzamos una lectura rápida de la última posición guardada en el caché del dispositivo
        fn_get_last_known_location_fast()

        val builder = Data.Builder()
        builder.putDouble("latitud", latitude)
        builder.putDouble("longitud", longitude)
        builder.putString("direccion", direccion)
        return builder.build()
    }

    private fun fn_get_last_known_location_fast() {
        locationManager = applicationContext.getSystemService(LOCATION_SERVICE) as LocationManager

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return
        }

        // Buscamos el último punto conocido de la red o del GPS instantáneamente
        val netLocation = locationManager!!.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
        val gpsLocation = locationManager!!.getLastKnownLocation(LocationManager.GPS_PROVIDER)

        // Elegimos la ubicación que no sea nula (priorizando el GPS por precisión)
        val mejorLocation = gpsLocation ?: netLocation

        if (mejorLocation != null) {
            latitude = mejorLocation.latitude
            longitude = mejorLocation.longitude
            // Opcional: invocar geocoder aquí si necesitas refrescar la variable 'direccion'
            devuelveDepartamentoNombre(latitude, longitude)
        }
    }

}