package com.estebanmiretti.gps

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Handler
import android.os.Looper
import android.preference.PreferenceManager
import android.util.Log
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.estebanmiretti.gps.polygon.Point
import com.estebanmiretti.gps.polygon.Polygon
import okhttp3.OkHttpClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.simplexml.SimpleXmlConverterFactory


class RssLocationWorker(appContext: Context, workerParams: WorkerParameters) :

    CoroutineWorker(appContext, workerParams) {

    //val MY_PERMISSIONS_REQUEST_CODE = 33
    //private var strarr = "-33.00 -65.10 -32.81 -65.87 -32.29 -65.68 -32.49 -64.95"

    var wvTodos: StringBuilder = StringBuilder("")

    //private var contains: Boolean = false
    var notificationId: Int = 15


    //val myRssLocationWork = OneTimeWorkRequest.from(RssLocationWorker::class.java)
    val context = appContext


    override suspend fun doWork(): Result {

        // Do the work here--in this case, upload the images.
        readXmlFeed()
        //Handler(Looper.getMainLooper()).post {Toast.makeText(context, "laburando " + inputData.getString("direccion"),Toast.LENGTH_SHORT).show()}

        // Indicate whether the work finished successfully with the Result
        return Result.success()
    }


    fun readXmlFeed() {

        val array: ArrayList<String> = ArrayList<String>()


        val latitud = inputData.getDouble("latitud", 0.0)
        val longitud = inputData.getDouble("longitud", 0.0)

        val retrofit = Retrofit.Builder()
            .baseUrl("https://ssl.smn.gob.ar/feeds/")
            //.baseUrl("https://meridianodigital.com.ar")
            .client(OkHttpClient())
            .addConverterFactory(SimpleXmlConverterFactory.create())
            .build();

        val reader: ApiDataInterface = retrofit.create(ApiDataInterface::class.java)

        val call: Call<Rss> = reader.getData()

        call.enqueue(object : Callback<Rss> {
            override fun onResponse(call: Call<Rss>, response: Response<Rss>) {
                val mPref = PreferenceManager.getDefaultSharedPreferences(context)
                val editor = mPref.edit()
                //array.clear()
                var rssmessage: Rss?
                var arrayDeptos: List<String>? = null
                if (response.isSuccessful) {
                    rssmessage = response.body()
                    //Handler(Looper.getMainLooper()).post {Toast.makeText(context, rssmessage?.getChannel()!!.getTitle(), Toast.LENGTH_SHORT).show() }
                    //prueba()
                    if (rssmessage != null) {
                        array.clear()
                        var arrayDeptosIsEmpty: Boolean = false

                        val strArrDeptos: String? = mPref.getString("deptos", null)
                        if (!strArrDeptos.isNullOrBlank()) {//.length>3)
                            arrayDeptos =
                                (strArrDeptos.replace("[", "")
                                    .replace("]", "")
                                    .replace("\"", "")).split(",")
                            //Handler(Looper.getMainLooper()).post { Toast.makeText(context,strArrDeptos + " :: " + arrayDeptos.toString(), Toast.LENGTH_SHORT).show() }
                        } else arrayDeptosIsEmpty = true
                        //?.toTypedArray()
                        var wv: String?
                        var lengs: String? = ""

                        for (leng in rssmessage.getChannel()?.getItem()!!) {
                            wv = leng?.getDescription()
                            array.add(
                                wv!!.replace("\n", "")
                                    .replace("\t", "")
                                    .replace("\r", "")
                            )

                            val poly2: Polygon.Builder = Polygon.Builder()


                            var i = 0

                            if (!arrayDeptosIsEmpty) {
                                var ii = 0
                                while (ii < arrayDeptos?.size!!) {
                                    if (wv.contains(arrayDeptos[ii], true)) {
                                        if (lengs.isNullOrEmpty()) lengs += arrayDeptos[ii]
                                        else lengs += ", " + arrayDeptos[ii]

                                        if (!wvTodos.isEmpty()) wvTodos.append("<br><hr>" + wv)
                                        else wvTodos.append(wv)
                                        //ii++
                                        break
                                    }
                                    ii++
                                }

                            }
                            val answer = leng!!.getPolygon()
                            if (answer != null) {
                                val arrayLatLng = answer.split(" ")
                                while (i < arrayLatLng.size) {
                                    poly2.addVertex(
                                        Point(
                                            java.lang.Double.valueOf(arrayLatLng.get(i)),
                                            java.lang.Double.valueOf(arrayLatLng.get(++i))
                                        )
                                    )
                                    i++
                                }
                                val polygon2 = poly2.build()
                                val point = Point(latitud, longitud)
                                if (polygon2.contains(point)) {
                                    if (lengs.isNullOrEmpty()) lengs += "Locación Actual"
                                    else lengs += ", " + "Locación Actual"

                                    if (!wvTodos.isNullOrEmpty()) wvTodos.append("<br><hr>" + wv)
                                    else wvTodos.append(wv)
                                }
                            }
                            /*if (polygon2.contains(point) || strCheck
                             || leng!!.getDescription()?.contains("Chaco", true)!!
                            || leng!!.getDescription()?.ctains("Castellanos", true)!!
                            || leng!!.getDescription()?.contains("Rosario", true)!! ){
                            //intent nuevo

                            Handler(Looper.getMainLooper()).post {
                            Toast.makeText(
                            context,
                            wv,
                            Toast.LENGTH_SHORT
                            ).show()
                            }*/
                            /*if (strCheck)
                                    notificationManager.notify(
                                        notificationId,
                                        createNotification(leng.getTitle()!!)
                                    )*/


                            //}/////else intent nuevo txtTitle.loadData("sin alerta "+count, "text/html", "UTF-8")

                        }
                        if (!lengs?.isNullOrEmpty()!!)//!wvTodos.toString()?.isNullOrEmpty()!!)
                            notificationManager.notify(
                                notificationId,
                                createNotification("Alertas: " + lengs)
                            )


                        /*Handler(Looper.getMainLooper()).post {
                        Toast.makeText(
                        context,
                        latitud.toString() + ", " + longitud.toString(),
                        Toast.LENGTH_SHORT
                        ).show()
                        }*/
                        if (!array.isEmpty() || array.size != 0)
                            editor.putString(
                                "alertas", convertStringArrayToString(array, "$")
                            )/*////// else
                            editor.putString(
                                "alertas", "Sin Alerta"
                            )*/

                    } else {
                        Handler(Looper.getMainLooper()).post {
                            Toast.makeText(
                                context,
                                "rss nulo",
                                Toast.LENGTH_SHORT
                            ).show()
                            if (!array.isEmpty() || array.size != 0)
                                editor.putString(
                                    "alertas", array.toString()
                                ) /*//////else
                                editor.putString(
                                    "alertas", "rss nulo"
                                )*/
                        }
                    }


                } else {

                    Handler(Looper.getMainLooper()).post {
                        Toast.makeText(
                            context,
                            "no response worker rss",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                    /*//////editor.putString(
                        "alertas", "no response worker rss"
                    )*/
                }
                editor.apply()
                editor.commit()
            }

            override fun onFailure(call: Call<Rss>, t: Throwable) {
                /*//////val mPref = PreferenceManager.getDefaultSharedPreferences(context)
                val editor = mPref.edit()
                editor.putString(
                    "alertas", "Algo falló)=" + t.message
                )
                editor.apply()
                editor.commit()*/
                t.message?.let { Log.e("Fail: ", it) }
                Handler(Looper.getMainLooper()).post {
                    Toast.makeText(
                        context,
                        "Falla temporaria en la web de SMN web: " + t.message,
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

        })

    }


    private val notificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    val channelId = context.getString(R.string.notification_channel_id)
    val name = context.getString(R.string.channel_name)
    val cancel = context.getString(R.string.cancel_processing)
    val title: String = "Aviso de Corto Plazo"

    /**
     * Create ForegroundInfo required to run a Worker in a foreground service.
     */
/*private fun createForegroundInfo(): ForegroundInfo {
// Use a different id for each Notification.
notificationId = 15
return ForegroundInfo(notificationId, createNotification())
}*/

    /**
     * Create the notification and required channel (O+) for running work
     * in a foreground service.
     */

    private fun createNotification(st: String): Notification {
// This PendingIntent can be used to cancel the Worker.
//val intent = WorkManager.getInstance(context).createCancelPendingIntent(id)
//val resultIntent = Intent(this.MainActivity.getBaseContext(), Alarma::class.java)
//val asdf: PendingIntent = PendingIntent.getActivity(this, 0, resultIntent, 0)
        val intent = Intent(context, Alarma::class.java)
        intent.putExtra("wv", wvTodos.toString())
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)

        val pendingIntent = PendingIntent.getActivity(
            context, 0 /* Request code */, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or
                    PendingIntent.FLAG_MUTABLE
            //PendingIntent.FLAG_UPDATE_CURRENT
//PendingIntent.FLAG_CANCEL_CURRENT
        )
        val builder = NotificationCompat.Builder(context, channelId)
            .setContentTitle(title)
//.setTicker("title")
            .setContentText(st)

            .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
            .setSmallIcon(android.R.drawable.alert_dark_frame)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
//.setCustomBigContentView()
            .setOnlyAlertOnce(true)
            .setAutoCancel(true)
            .setOngoing(true)
//.addAction(R.drawable.ic_baseline_delete_24, cancel, intent)
        createNotificationChannel(channelId, name).also {
            builder.setChannelId(it.id).setPriority(NotificationCompat.PRIORITY_HIGH)
        }
        return builder.build()
    }

    /**
     * Create the required notification channel for O+ devices.
     */
    private fun createNotificationChannel(
        channelId: String,
        name: String
    ): NotificationChannel {
        return NotificationChannel(
            channelId, name, NotificationManager.IMPORTANCE_HIGH
        ).also { channel ->
            notificationManager.createNotificationChannel(channel)
        }
    }

    fun prueba() {
        var polygon: Polygon.Builder? = Polygon.Builder()
            .addVertex(Point(-23.30, -62.04))
            .addVertex(Point(-24.04, -60.71))
            .addVertex(Point(-24.43, -60.91))
            .addVertex(Point(-23.72, -62.17))

//.addVertex(Point(3.0, 1.0))
//.build()


// contains = polygon!!.build().contains(point)
    }

    private fun convertStringArrayToString(strArr: ArrayList<String>, delimiter: String): String? {
        val sb = StringBuilder()
        for (str in strArr) sb.append(str).append(delimiter)
        return sb.substring(0, sb.length - 1)
    }
}