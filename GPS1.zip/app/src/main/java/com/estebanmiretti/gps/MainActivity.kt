package com.estebanmiretti.gps

import android.*
import android.Manifest.permission.ACCESS_FINE_LOCATION
import android.app.Activity
import android.app.ActivityManager
import android.content.*
import android.content.pm.PackageManager
import android.os.*
import android.preference.PreferenceManager
import android.text.Html
import android.text.Spanned
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.*
import android.widget.TextView

import android.view.ViewGroup
import android.webkit.WebView

import android.widget.ArrayAdapter
import androidx.activity.result.contract.ActivityResultContracts


class MainActivity : AppCompatActivity() {

    private lateinit var intento: Intent
    private var localidad: String? = null
    private var provincia: String? = null
    private var direccion: String? = null
    private var departamento: String? = null
    var latitud: Double = 0.0
    var longitud: Double = 0.0
    var mBound: Boolean = false
    var mService: GoogleService? = null
    //var btn_start: Button? = null
    private val REQUEST_PERMISSIONS = 100
    var boolean_permission = false
    //var tv_latitude: TextView? = null
    //var tv_longitude: TextView? = null
    var tv_address: TextView? = null
    //var tv_area: TextView? = null
    //var tv_locality: TextView? = null
    //var subadminarea: TextView? = null
    private lateinit var adapter: ArrayAdapter<String>
    private var array1: Array<String>? = arrayOf("init")


    private fun isMyServiceRunning(serviceClass: Class<*>): Boolean {
        val manager = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        for (service in manager.getRunningServices(Int.MAX_VALUE)) {
            if (serviceClass.name == service.service.className) {
                return true
            }
        }
        return false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //array1 = resources.getStringArray(R.array.q)
        //btn_start = findViewById<View>(R.id.btn_start) as Button
        tv_address = findViewById<View>(R.id.tv_address) as TextView
        /*tv_locality = findViewById<View>(R.id.tv_locality) as TextView
        tv_latitude = findViewById<View>(R.id.tv_latitude) as TextView
        tv_longitude = findViewById<View>(R.id.tv_longitude) as TextView
        tv_area = findViewById<View>(R.id.tv_area) as TextView

        subadminarea = findViewById<View>(R.id.subadminarea) as TextView*/
        //geocoder = Geocoder(this, Locale.getDefault())
        fn_permission()



    }

    private fun getAlerta(s: String) {


    }



    fun doBindService() {
        if (!mBound && !isMyServiceRunning(GoogleService::class.java)) {
            Toast.makeText(
                applicationContext,
                "Iniciando servicio",
                Toast.LENGTH_SHORT
            ).show()

            intento = Intent(applicationContext, GoogleService::class.java)

            mService?.startService(intento)
            bindService(intento, mConnection, BIND_AUTO_CREATE)
        }
        //Service is active
        else if (!mBound/* && isMyServiceRunning(GoogleService::class.java)*/) {
            //if(btn_start?.text != "Cerrar") {
                bindService(intento, mConnection, BIND_AUTO_CREATE)
               //////Toast.makeText(this@MainActivity, "Servicio ya activo", Toast.LENGTH_SHORT).show()
            //}else finish()
        } else {
            //////Toast.makeText(this@MainActivity, "Servicio ya bindeado", Toast.LENGTH_SHORT).show()
        }
    }

    private fun fn_permission() {
        if (ContextCompat.checkSelfPermission(
                applicationContext,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(
                    this@MainActivity,
                    android.Manifest.permission.ACCESS_FINE_LOCATION
                )
            ) {
            } else {
                ActivityCompat.requestPermissions(
                    this@MainActivity, arrayOf(
                        android.Manifest.permission.ACCESS_FINE_LOCATION
                    ),
                    REQUEST_PERMISSIONS
                )
            }
        } else {
            boolean_permission = true
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String?>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            REQUEST_PERMISSIONS -> {
                if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    boolean_permission = true
                } else {
                    Toast.makeText(
                        applicationContext,
                        "Por favor, habilite el permiso",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    private val broadcastReceiver: BroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent) {
            latitud = intent.getDoubleExtra("latutide", 0.0)
            longitud = intent.getDoubleExtra("longitude", 0.0)
            localidad = intent.getStringExtra("localidad")
            departamento = intent.getStringExtra("departamento")
            direccion = intent.getStringExtra("direccion")
            provincia = intent.getStringExtra("provincia")
            Log.e("gps clima", "Datos cargando..."+latitud)
            cargarDatos()
            adapter!!.notifyDataSetChanged()
        }
    }

    private fun cargarDatos() {

        tv_address!!.setText("Chequeando clima en " + direccion)

        val mPref = PreferenceManager.getDefaultSharedPreferences(applicationContext)
        val arrayText: String? = mPref.getString("alertas", "Inicializando...")
        val myListView = findViewById<ListView>(R.id.ListView01)
        myListView.layoutDirection



        myListView.onItemClickListener = AdapterView.OnItemClickListener { parent, _, position, _ ->
            val selectedFromList = parent.getItemAtPosition(position) as String
            //getAlerta("$selectedFromList")
        }
        if (arrayText != null) {
            array1 = arrayText.split("$").toTypedArray()
            myListView.adapter = null
        }

         adapter =
            object : ArrayAdapter<String>(this, R.layout.new_list_view, array1!!) {
                override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                    val row: View
                    row = convertView ?: getLayoutInflater().inflate(R.layout.new_list_view, null)
                    val tv = row.findViewById<View>(android.R.id.text1) as WebView//findViewById<WebView>(R.id.webview) as WebView
                    tv.loadData(
                        "<html><head><style>body{margin-left: auto; margin-top: 20px; margin-right: auto; max-width: 85%;}img{display: inline; height: auto;display: block; margin-left: auto; margin-right: auto; max-width: 100%; }</style>\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"></head>\n<body>"
                                + getItem(position)
                                + "</body></html>", "text/html", "UTF-8"
                    )
                    return row
                }
            }


        myListView.adapter = this.adapter


    }



    override fun onPause() {
        unregisterReceiver(broadcastReceiver)
        if (mBound) {
            unbindService(mConnection)
            mBound = false
        }
        //mService?.stopSelf()
        super.onPause()

    }

    /*override fun onResume() {
        super.onResume()
        mService?.fn_getlocation();
    }*/


    override fun onResume() {
        super.onResume()
        doBindService()

        registerReceiver(broadcastReceiver, IntentFilter(GoogleService.str_receiver))
        //mService?.fn_getlocation()

       cargarDatos()


        /*btn_start!!.setOnClickListener {
            if (boolean_permission) {
                /* val mPref: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(baseContext)
                 val medit: SharedPreferences.Editor = mPref.edit()
                 val serv: String? = mPref.getString("service", "")*/
                if (!mBound) {
                    //medit.putString("service", "service").commit()
                    ////val intent = Intent(applicationContext, GoogleService::class.java)
                    ////startService(intent)
                    //doBindService()
                    Toast.makeText(this, "Servicio Inactivo", Toast.LENGTH_SHORT)
                        .show()
                    //cargarDatos()
                   // btn_start!!.setText("Cerrar")
                } else if (applicationContext != null && mService != null){
                    Toast.makeText(applicationContext, "unbind", Toast.LENGTH_SHORT)
                        .show()
                    //unbindService(mConnection)
                    //unregisterReceiver(broadcastReceiver)
                    //mBound = false

                    ////val intent = Intent(applicationContext, GoogleService::class.java)
                    ////stopService(intent)
                    //finish()
                   // btn_start!!.setText("Leer Locación y su alerta")
                }
                //////cargarDatos()
            } else {
                Toast.makeText(this, "Por favor conecte el gps", Toast.LENGTH_SHORT)
                    .show()

            }
        }*/
    }

    /*public Handler myHandler = new Handler() {
        public void handleMessage(Message message) {
            Bundle data = message.getData();
        }
    };

    public void doBindService() {
        Intent intent = null;
        intent = new Intent(this, MediaPlayerService.class);
        // Create a new Messenger for the communication back
        // From the Service to the Activity
        Messenger messenger = new Messenger(myHandler);
        intent.putExtra("MESSENGER", messenger);

        bindService(intent, myConnection, Context.BIND_AUTO_CREATE);
    }*/
    override fun onBackPressed() {
        super.onBackPressed()
        Log.e("GPS", "adio")
        //unbind();
        mService?.stopSelf()
        finish()
    }

    /**
     * Defines callbacks for service binding, passed to bindService()
     */
    private val mConnection: ServiceConnection = object : ServiceConnection {
        override fun onServiceConnected(
            className: ComponentName,
            service: IBinder
        ) {
            //Toast.makeText(this@MainActivity, "Servicio conectado", Toast.LENGTH_SHORT).show()
            // We've bound to LocalService, cast the IBinder and get LocalService instance
            val binder: GoogleService.LocalBinder = service as GoogleService.LocalBinder
            mService = binder.getService()
            mBound = true
/////cargarDatos()
        }

        override fun onServiceDisconnected(arg0: ComponentName) {
            mBound = false
            Toast.makeText(this@MainActivity, "Servicio desconectado", Toast.LENGTH_SHORT).show()

        }
    }
    override fun onSaveInstanceState(savedInstanceState: Bundle) {
        super.onSaveInstanceState(savedInstanceState)
        savedInstanceState.putBoolean("ServiceState", mBound)
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        mBound = savedInstanceState.getBoolean("ServiceState")
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.menu, menu)
        return true
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        val i = Intent(this, NuevoDepartamento::class.java)

        when (id) {
            R.id.AgregarDepartamento -> {

                launchSomeActivity.launch(i)
            }

        }

        return super.onOptionsItemSelected(item)
    }
    var launchSomeActivity =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val data: Intent? = result.data
                Toast.makeText(applicationContext,"Alerta agregada: "+data?.getStringExtra("variable").toString(), Toast.LENGTH_SHORT).show()
                //getTemperature(data!!.getStringExtra("variable").toString())
//onResume()

            }
        }
}